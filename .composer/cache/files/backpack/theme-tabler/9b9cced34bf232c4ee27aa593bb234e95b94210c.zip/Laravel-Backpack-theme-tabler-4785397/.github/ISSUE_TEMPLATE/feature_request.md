---
name: Feature Request
about: Tell us about a feature you think will appeal to a lot of our users
title: "[Feature Request] Quick summary here"
---

# Feature Request

### What I am trying to achieve

Write your answer here.

### How I see it implemented

Write your answer here.

### What I've already tried to fix it

Write your answer here.

### Would I be able to work on this myself and submit a PR

Write your answer here.
