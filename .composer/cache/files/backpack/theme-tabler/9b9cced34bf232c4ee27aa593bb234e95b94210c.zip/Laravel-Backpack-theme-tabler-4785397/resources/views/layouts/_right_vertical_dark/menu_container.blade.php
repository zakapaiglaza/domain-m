@extends(backpack_view('layouts._vertical.menu_container'), [
    'right' => true,
    'theme' => 'dark',
])
