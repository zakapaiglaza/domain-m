<?php

return [
    // color mode
    'color-mode-description' => ':mode renk modu kullanılıyor',
    'color-mode-system' => 'sistem',
    'color-mode-light' => 'açık',
    'color-mode-dark' => 'koyu',
];
