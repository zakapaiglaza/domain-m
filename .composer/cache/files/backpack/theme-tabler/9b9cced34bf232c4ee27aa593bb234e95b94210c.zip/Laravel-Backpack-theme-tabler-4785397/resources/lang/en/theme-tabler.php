<?php

return [
    // color mode
    'color-mode-description' => 'Using :mode color mode',
    'color-mode-system' => 'system',
    'color-mode-light' => 'light',
    'color-mode-dark' => 'dark',

    // password
    'password-show' => 'Show password',
    'password-hide' => 'Hide password',
];
