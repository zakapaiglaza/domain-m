<?php

return [
    // color mode
    'color-mode-description' => 'A utilizar o modo :mode',
    'color-mode-system' => 'predefinido do sistema',
    'color-mode-light' => 'claro',
    'color-mode-dark' => 'escuro',

    // password
    'password-show' => 'Mostrar password',
    'password-hide' => 'Esconder password',
];
