<div class="dropdown-menu-column">
{!! $slot !!}
</div>