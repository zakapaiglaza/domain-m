@extends(backpack_view('layouts._vertical.menu_container'), [
    'theme' => 'transparent',
    'shortcuts' => false,
    'auth' => false,
])
