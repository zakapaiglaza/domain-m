<?php

return [
    // color mode
    'color-mode-description' => 'Đang sử dụng chế độ màu :mode',
    'color-mode-system' => 'hệ thống',
    'color-mode-light' => 'sáng',
    'color-mode-dark' => 'tối',

    // password
    'password-show' => 'Hiện mật khẩu',
    'password-hide' => 'Ẩn mật khẩu',
];
