<?php

return [
    // color mode
    'color-mode-description' => 'Modalità tema :mode',
    'color-mode-system' => 'sistema',
    'color-mode-light' => 'chiaro',
    'color-mode-dark' => 'scuro',

    // password
    'password-show' => 'Mostra password',
    'password-hide' => 'Nascondi password',
];

