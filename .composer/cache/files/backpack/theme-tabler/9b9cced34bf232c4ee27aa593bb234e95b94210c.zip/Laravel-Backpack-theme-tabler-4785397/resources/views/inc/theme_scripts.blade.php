@basset('https://cdn.jsdelivr.net/npm/@tabler/core@1.4.0/dist/js/tabler.min.js', true, ['integrity' => 'sha256-tgx2Fg6XYkV027jPEKvmrummSTtgCW/fwV3R3SvZnrk=', 'crossorigin' => 'anonymous'])
@basset(base_path('vendor/backpack/theme-tabler/resources/assets/js/tabler.js'))
