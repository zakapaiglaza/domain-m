@extends(backpack_view('layouts._horizontal.menu_container'), [
    'theme' => 'dark',
])
