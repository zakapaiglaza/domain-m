<span {{ $attributes->merge(['class' => 'nav-separator']) }}>{{ $title }}</span>
