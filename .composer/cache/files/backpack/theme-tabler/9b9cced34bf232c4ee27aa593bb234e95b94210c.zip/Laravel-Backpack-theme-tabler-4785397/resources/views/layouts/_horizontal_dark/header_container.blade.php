@extends(backpack_view('layouts._horizontal.header_container'), [
    'theme' => 'dark',
])