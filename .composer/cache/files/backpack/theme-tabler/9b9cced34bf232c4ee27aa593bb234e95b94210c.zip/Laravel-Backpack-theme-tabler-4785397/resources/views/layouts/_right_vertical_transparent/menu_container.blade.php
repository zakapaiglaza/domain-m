@extends(backpack_view('layouts._vertical.menu_container'), [
    'right' => true,
    'theme' => 'transparent',
    'shortcuts' => false,
    'auth' => false,
])
